
## Encoding audit (Experiment 009)

The [interactive encoding audit](encyclopedia/studies/009-encoding-audit.html) distinguishes recipient-linked graphic categories from source-defined distinct mechanisms. It offers uniform, original and symbol-swapping studies plus a separate rate-normalization control. See the [research conclusion](encyclopedia/studies/009-encoding-audit.md). The result is a source/code review and a design instrument, not evidence of human comprehension.
